<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>izquierdo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
 <h3>Listas</h3>
 <h5><a href="consulta_equipos.php" title="Listado de equipos" target="mainFrame">Equipos</a></h5>
 <h5><a href="consulta_carreras_por_equipo.php" title="Carreras por equipo" target="mainFrame">Equipos por carrera</a></h5>
 <h3>Altas</h3>
 <h4><a href="alta_alumno_equipo.php" title="Alumno equipo" target="mainFrame">Alumno</a></h4>
 <p>&nbsp;</p>
</body>
</html>
