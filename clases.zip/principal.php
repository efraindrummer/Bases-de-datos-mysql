<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<title>Documento sin t&iacute;tulo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<frameset rows="*" cols="188,*" framespacing="0" frameborder="NO" border="0">
  <frame src="izquierdo.php" name="leftFrame" scrolling="NO" noresize>
  <frame src="derecho.php" name="mainFrame">
</frameset>
<noframes><body>
</body></noframes>
</html>
