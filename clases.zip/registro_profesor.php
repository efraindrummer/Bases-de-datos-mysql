<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Registro</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p align="center">Registro de profesores </p>
<form name="form1" method="post" action="">
  <table width="200" border="1" align="center">
    <tr>
      <td>Nombre:</td>
      <td><input type="text" name="textfield"></td>
    </tr>
    <tr>
      <td>Apellido:</td>
      <td><input type="text" name="textfield2"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Enviar">
      <input type="reset" name="Submit2" value="Limpiar"></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
</body>
</html>
