<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Fiesta mexicana</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.Estilo1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: medium;
	color: #000066;
}
-->
</style>
</head>
<body>
<p align="center" class="Estilo1">Bienvenidos</p>
<p align="center" class="Estilo1">Fiesta mexicana</p>
</body>
</html>
