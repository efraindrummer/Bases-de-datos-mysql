<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Derecho</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.Estilo1 {color: #003300}
-->
</style>
</head>

<body>
<div align="center">
  <p><img src="images/LOGO_UNACAR_BN.png" width="551" height="127"></p>
  <h1 class="Estilo1">Bienvenido a la </h1>
  <h1 class="Estilo1">&iexcl;Fiesta Nacional Mexicana!</h1>
  <p> 
    <img src="images/sombrero_maracas.jpg" width="283" height="178"></p>
  <h1 class="Estilo1">Muestra gaston&oacute;mica </h1>
</div>
</body>
</html>
